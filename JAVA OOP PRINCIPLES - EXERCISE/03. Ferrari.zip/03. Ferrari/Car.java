package ferrari;

public interface Car {

    String useBreaks();
    String pushGasPedal();
}
