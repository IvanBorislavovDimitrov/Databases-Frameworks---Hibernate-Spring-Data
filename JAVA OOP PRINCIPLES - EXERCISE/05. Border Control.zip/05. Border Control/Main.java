package border_control;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class Main {

    public static void main(String[] args) throws IOException {
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        List<Entry> entries = new ArrayList<>();
        String line;

        while (! (line = input.readLine()).equals("End")) {
            String[] infoAboutEntry = line.split("\\s+");
            if (infoAboutEntry.length == 2) {
                Entry robot = new Robot(infoAboutEntry[0], infoAboutEntry[1]);
                entries.add(robot);
            } else if (infoAboutEntry.length == 3) {
                Entry person = new Person(infoAboutEntry[0], Integer.parseInt(infoAboutEntry[1]), infoAboutEntry[2]);
                entries.add(person);
            }
        }

        String lastCharsOfId = input.readLine();

        for (Entry entry : entries) {
            if (entry.getId().endsWith(lastCharsOfId)) {
                System.out.println(entry.getId());
            }
        }
    }
}
