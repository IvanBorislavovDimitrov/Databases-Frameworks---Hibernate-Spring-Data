package define_interface_person;

public interface Person {

    int getAge();
    String getName();
}
