package define_interface_person;

public interface Birthable {

    String getBirthdate();
}
