package telephony;

public interface Smartphone extends Phone{

    void browseInWww(String url);
}
