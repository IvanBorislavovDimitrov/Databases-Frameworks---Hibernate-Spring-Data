package telephony;

public interface Phone {

    void call(String receiver);
}
