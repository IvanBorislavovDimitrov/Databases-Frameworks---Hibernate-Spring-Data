package vehicles;

import java.text.DecimalFormat;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        String[] infoAboutCar =  input.nextLine().split("\\s+");
        double fuelForCar = Double.parseDouble(infoAboutCar[1]);
        double fuelConsumptionForCar = Double.parseDouble(infoAboutCar[2]);
        String[] infoAboutTruck = input.nextLine().split("\\s+");
        double fuelForTruck = Double.parseDouble(infoAboutTruck[1]);
        double fuelConsumptionForTruck = Double.parseDouble(infoAboutTruck[2]);

        Vehicle car = new Car(fuelForCar, fuelConsumptionForCar);
        Vehicle truck = new Truck(fuelForTruck, fuelConsumptionForTruck);

        int countOfCommands = Integer.parseInt(input.nextLine());

        for (int i = 0; i < countOfCommands; i++) {
            String[] lineArgs = input.nextLine().split("\\s+");
            String command = lineArgs[0];
            String vehicle = lineArgs[1];
            switch (command) {
                case "Drive":
                    double km = Double.parseDouble(lineArgs[2]);
                    if (vehicle.equals("Car")) {
                        car.drive(km);
                    } else if (vehicle.equals("Truck")) {
                        truck.drive(km);
                    }
                    break;
                case "Refuel":
                    double quantity = Double.parseDouble(lineArgs[2]);
                    if (vehicle.equals("Car")) {
                        car.refuel(quantity);
                    } else if (vehicle.equals("Truck")) {
                        truck.refuel(quantity);
                    }
                    break;
            }
        }

        double carFuel = car.getFuelQuantity();
        double truckFuel = truck.getFuelQuantity();
        System.out.println(String.format("Car: %.2f", carFuel));
        System.out.println(String.format("Truck: %.2f", truckFuel));

    }
}
