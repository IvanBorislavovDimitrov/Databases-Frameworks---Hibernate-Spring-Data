package vehicles;

import java.text.DecimalFormat;

public class Car extends Vehicle {

    public Car(double fuelQuantity, double fuelConsumptionPerKm) {
        super(fuelQuantity, fuelConsumptionPerKm);
    }

    @Override
    protected void drive(double km) {
        double usedFuel = km * (this.getFuelConsumptionPerKm() + 0.9d);
        if (this.getFuelQuantity() < usedFuel) {
            System.out.println("Car needs refueling");
        } else {
            this.distanceTravelled += km;
            this.setFuelQuantity(this.getFuelQuantity() - usedFuel);
            DecimalFormat df = new DecimalFormat("####.##");
            System.out.println(String.format("Car travelled %s km", df.format(km)));
        }
    }

    @Override
    protected void refuel(double litres) {
        this.setFuelQuantity(this.getFuelQuantity() + litres);
    }
}
