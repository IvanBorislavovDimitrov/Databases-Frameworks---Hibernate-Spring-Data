package vehicles;

import java.text.DecimalFormat;

public class Truck extends Vehicle {
    public Truck(double fuelQuantity, double fuelConsumptionPerKm) {
        super(fuelQuantity, fuelConsumptionPerKm);
    }

    @Override
    protected void drive(double km) {
        double usedFuel = km * (this.getFuelConsumptionPerKm() + 1.6d);
        if (this.getFuelQuantity() < usedFuel) {
            System.out.println("Truck needs refueling");
        } else {
            this.distanceTravelled += km;
            this.setFuelQuantity(this.getFuelQuantity() - usedFuel);
            DecimalFormat df = new DecimalFormat("####.##");
            System.out.println(String.format("Truck travelled %s km", df.format(km)));
        }
    }

    @Override
    protected void refuel(double litres) {
        this.setFuelQuantity(this.getFuelQuantity() + litres * 0.95);
    }
}
