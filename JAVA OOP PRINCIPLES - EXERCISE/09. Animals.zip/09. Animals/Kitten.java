package animals;

public class Kitten extends Cat {

    @Override
    protected String produceSound() {
        return "Miau";
    }
}
