package animals;

public class Cat extends Animal {

    @Override
    protected String produceSound() {
        return "MiauMiau";
    }
}
