package animals;

public class Frog extends Animal {

    @Override
    protected String produceSound() {
        return "Frogggg";
    }
}
