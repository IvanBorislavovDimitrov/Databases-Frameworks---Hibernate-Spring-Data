package animals;

public class Dog extends Animal {

    @Override
    protected String produceSound() {
        return "BauBau";
    }
}
