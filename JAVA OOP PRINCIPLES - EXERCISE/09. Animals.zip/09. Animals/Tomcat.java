package animals;

public class Tomcat extends Cat {

    @Override
    protected String produceSound() {
        return "Give me one million b***h";
    }
}
