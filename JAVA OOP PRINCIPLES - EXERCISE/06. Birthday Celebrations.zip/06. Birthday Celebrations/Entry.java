package border_control;

public interface Entry {

    String getBirthdate();
}
