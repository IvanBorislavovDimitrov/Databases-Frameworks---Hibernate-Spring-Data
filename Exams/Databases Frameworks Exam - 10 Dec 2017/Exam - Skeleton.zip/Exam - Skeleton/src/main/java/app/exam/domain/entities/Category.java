package app.exam.domain.entities;

public class Category {

}
