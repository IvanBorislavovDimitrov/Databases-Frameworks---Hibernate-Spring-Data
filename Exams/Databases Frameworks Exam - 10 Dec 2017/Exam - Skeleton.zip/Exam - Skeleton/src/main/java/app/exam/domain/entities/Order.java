package app.exam.domain.entities;

public class Order {

}
