package app.exam.domain.entities;

public enum OrderType {
    ForHere, ToGo
}
