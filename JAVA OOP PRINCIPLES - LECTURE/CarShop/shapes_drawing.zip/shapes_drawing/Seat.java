package car_shop;

import java.io.Serializable;

public class Seat implements Car, Serializable {

    private String model;
    private String color;
    private int horsePower;
    private String country;

    public Seat(String model, String color, int horsePower, String country) {
        this.model = model;
        this.color = color;
        this.horsePower = horsePower;
        this.country = country;
    }

    @Override
    public int getTires() {
        return tires;
    }

    @Override
    public String getModel() {
        return this.model;
    }

    @Override
    public String getColor() {
        return this.color;
    }

    @Override
    public int getHorsePower() {
        return this.horsePower;
    }

    public String getCountry() {
        return this.country;
    }

    @Override
    public String toString() {
        return String.format("This is Leon produced in %s and have %d tires", this.country, tires);
    }
}
