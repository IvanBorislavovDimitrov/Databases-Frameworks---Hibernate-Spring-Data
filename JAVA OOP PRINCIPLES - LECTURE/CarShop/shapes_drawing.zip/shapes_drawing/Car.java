package car_shop;

public interface Car {

    int tires = 4;

    int getTires();

    String getModel();

    String getColor();

    int getHorsePower();
}
