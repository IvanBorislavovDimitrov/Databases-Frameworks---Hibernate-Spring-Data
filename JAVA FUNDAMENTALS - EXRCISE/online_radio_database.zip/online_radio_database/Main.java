package online_radio_database;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Struct;
import java.util.ArrayList;
import java.util.List;

public class Main {

    static class Song {

        public Song(String artistName, String name, int minutes, int second) {
            this.artistName = artistName;
            this.name = name;
            this.minutes = minutes;
            this.second = second;
        }

        private String artistName;
        private String name;
        private int minutes;
        private int second;

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public int getMinutes() {
            return minutes;
        }

        public String getArtistName() {
            return artistName;
        }

        public void setArtistName(String artistName) {
            this.artistName = artistName;
        }

        public void setMinutes(int minutes) {
            this.minutes = minutes;
        }

        public int getSecond() {
            return second;
        }

        public void setSecond(int second) {
            this.second = second;
        }
    }

    public static void main(String[] args) throws IOException {
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));

        int countOfSongs = Integer.parseInt(input.readLine());
        List<Song> songs = new ArrayList<>();

        for (int i = 0; i < countOfSongs; i++) {
            try {
                String[] infoAboutSong = input.readLine().split(" *;+ *");
                String authorName = infoAboutSong[0];
                String songName = infoAboutSong[1];
                String[] num = infoAboutSong[2].split(" *:+ *");
                if (num[0].equals("") || num[1].equals("")) {
                    throw new InvalidSongException("Invalid song.");
                }
                int minutes = Integer.parseInt(num[0]);
                int seconds = Integer.parseInt(num[1]);

                if (authorName.length() < 3 || authorName.length() > 20) {
                    throw new InvalidArtistNameException("Artist name should be between 3 and 20 symbols.");
                }
                if (songName.length() < 3 || songName.length() > 30) {
                    throw new InvalidSongNameException("Song name should be between 3 and 30 symbols.");
                }
                if (minutes > 14) {
                    throw new InvalidSongMinutesException("Song minutes should be between 0 and 14.");
                }
                if (seconds > 59) {
                    throw new InvalidSongMinutesException("Song seconds should be between 0 and 59.");
                }

                Song song = new Song(authorName, songName, minutes, seconds);
                songs.add(song);

                System.out.println("Song added.");
            } catch (InvalidSongException e) {
                System.out.println(e.getMessage());
            }  catch (NumberFormatException e) {
                System.out.println("Invalid song length.");
            }
        }

        System.out.println(String.format("Songs added: %d", songs.size()));
        long allSeconds = getAllSeconds(songs);
        long hours = allSeconds / 3600;
        long minutes = allSeconds / 60 % 60;
        long seconds = allSeconds % 60 ;

        System.out.println(String.format("Playlist length: %dh %dm %ds", hours, minutes, seconds));
    }

    private static long getAllSeconds(List<Song> songs) {
        long seconds = 0;
        for (Song song : songs) {
            seconds += song.getMinutes() * 60 + song.getSecond();
        }

        return seconds;
    }
}
